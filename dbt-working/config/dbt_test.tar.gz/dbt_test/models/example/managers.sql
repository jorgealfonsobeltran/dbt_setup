
/*
    Welcome to your first dbt model!
    Did you know that you can also configure models directly within SQL files?
    This will override configurations stated in dbt_project.yml

    Try changing "table" to "view" below
*/

{{ config(materialized='table') }}

select
  worker.id,
  worker.name,
  manager.name as manager_name,
  manager_2.name as manager_of_manager

from worker as worker
join
    worker manager
on 
    worker.manager=manager.id
join
    worker manager_2
on 
    manager.manager=manager_2.id
/*
    Uncomment the line below to remove records with null `id` values
*/

-- where id is not null
